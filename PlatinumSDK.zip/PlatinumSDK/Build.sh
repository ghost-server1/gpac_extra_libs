#!/bin/sh -e
if [ $# -ne 1 ] ; then
  echo "Usage: `basename $0` scons_platform"
  exit 1
fi

cd Platinum
scons -j 4
if [ $? != 0 ] ; then
	exit 1
fi

