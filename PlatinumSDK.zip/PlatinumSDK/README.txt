Platinum Kit
------------

The Platinum Kit contains all the software packages necessary to build the Platinum framework and sample applications. Each one of those software packages is contained in a directory at the top level of the Platinum Kit distribution.

The file VERSION.txt contains the version information of all the modules included in this kit.

The top-level modules are:

Platinum
--------
The Platinum framework and applications are located in the Platinum top-level directory. Also located there, in Platinum/README.txt and under the 'Platinum/Docs' sub-directory, are documentation files with more details about how to build and use the Platinum SDK.

Neptune
-------
Neptune is a portable C++ runtime class library. It is used by the Platinum implementation in the part of the implementation written in C++.
